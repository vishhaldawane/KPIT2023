package com.kpit.flower;

public class Lotus implements Flower {
	public Lotus() {
		System.out.println("Lotus() "+this);
	}
	public void flowering() {
        System.out.println("Lotus is flowering...");   
      }    
  } 