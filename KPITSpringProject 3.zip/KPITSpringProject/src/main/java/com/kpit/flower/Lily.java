package com.kpit.flower;

public class Lily implements Flower {
	public Lily() {
		System.out.println("Lily().."+this);
	}
    public void flowering() {
        System.out.println("Lily is flowering...");   
      }    
  } 
