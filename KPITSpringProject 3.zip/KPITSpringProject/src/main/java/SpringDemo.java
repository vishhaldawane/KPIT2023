

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.kpit.flower.Flower;

public class SpringDemo {

	public static void main(String[] args) {
		
		System.out.println("Trying to create spring container....");
		ApplicationContext container = new ClassPathXmlApplicationContext("myspring.xml");
		System.out.println("Got the spring container...");
		
		System.out.println("\tRequesting the container to give me rose object...");
		
		Flower flower = (Flower) container.getBean("roses");
		System.out.println("\tflower  : "+flower);
		
		Flower flower2 = (Flower) container.getBean("roses");
		System.out.println("\tflower2 : "+flower2);
		
		System.out.println("\tGot a bean from the container...");
		flower.flowering();
	}

}




