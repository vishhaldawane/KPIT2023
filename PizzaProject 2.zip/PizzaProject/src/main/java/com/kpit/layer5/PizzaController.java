package com.kpit.layer5;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kpit.layer2.Pizza;
import com.kpit.layer4.PizzaService;

@RestController
@RequestMapping("/dominos")
public class PizzaController {

	@Autowired
	PizzaService pizzaService; //would talk with the chef | PizzaRepository
	
	public PizzaController() {
		System.out.println("PizzaController()");
	}
	
	
	@RequestMapping("/pizza/{id}") //localhost:8080/dominos/pizza/1
	public Pizza getPizza(@PathVariable("id") Integer pid) {
		System.out.println("Pizza Controller is ordering Pizza from the PizzaService....");
		
		return pizzaService.orderingAPizza(pid);
	}

	@RequestMapping("/pizzas") //localhost:8080/dominos/pizzas
	public List<Pizza> getPizzas() {
		System.out.println("Pizza Controller is retrieving all Pizzas from the PizzaService....");
		
		return pizzaService.getAllPizzas();
	}

}
