package com.kpit;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.kpit.layer2.Pizza;
import com.kpit.layer4.PizzaService;

@SpringBootTest
public class PizzaServiceTesting {


	@Autowired
	PizzaService pizzaService;

	@Test
	public void findASinglePizzaServiceTest() {
		
		Pizza pizza = pizzaService.orderingAPizza(1);
		System.out.println("Pizza id    : "+pizza.getPizzaId());
		System.out.println("Pizza type  : "+pizza.getPizzaType());
		System.out.println("Pizza price : "+pizza.getPizzaPrice());
		
		
	}
}
