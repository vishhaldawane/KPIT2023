

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.kpit.cars.Car;
import com.kpit.flower.Flower;

public class SpringCarDemo2 {

	public static void main(String[] args) {
		
		System.out.println("Trying to create spring container....");
		ApplicationContext container = new ClassPathXmlApplicationContext("myspring_car2.xml");
		System.out.println("Got the spring container...");
		
		System.out.println("\tRequesting the container to give me Car's object...");
		System.out.println("--------------------------");
		Car car1 = (Car) container.getBean("myCar");
		System.out.println("Car 1 : "+car1.hashCode());
		
		System.out.println("-------------");
		
		Car car2 = (Car) container.getBean("myCar");
		System.out.println("Car 2 : "+car2.hashCode());

		System.out.println("-------------");

		
		Car car3 = (Car) container.getBean("myCar");
		System.out.println("Car 3 : "+car3.hashCode());

	}

}




