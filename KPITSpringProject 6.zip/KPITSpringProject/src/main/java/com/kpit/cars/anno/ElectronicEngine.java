package com.kpit.cars.anno;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("myElectronicEngine") //ctrl +shift +M will autoimport
public class ElectronicEngine extends Engine
{
	Piston piston;
	
	@Autowired
	public ElectronicEngine(Piston piston) {
		super(piston);
		System.out.println("ElectronicEngine(Piston)...."+this.hashCode());
		//this.piston = piston;
	}
	
	/*public Engine() {
		System.out.println("Engine()...");
	}*/
	
	public void setPetrolEngine(Piston piston) { //property = engine
		System.out.println("setElectronicEngine(Piston)....<==invoked ");

		this.piston = piston;
	}
	void startPetrolEngine() {
		System.out.println("ElectronicEngine is ignited....");
	}
}