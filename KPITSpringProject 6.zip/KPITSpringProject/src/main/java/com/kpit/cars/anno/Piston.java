package com.kpit.cars.anno;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("myPiston")
public class Piston {
	String name;
	
	
	public Piston(@Value("4Stroke") String name) {
		System.out.println("Piston(String)...."+this.hashCode());
		this.name = name;
	}
	
	/*public Piston() {
		System.out.println("Piston()...");
	}*/
	
	public void setPiston(String name) { //property  = piston
		System.out.println("setPiston(String)....<==invoked.");
		this.name = name;
	}
	
	void startPiston() {
		System.out.println("Piston is fired....");
	}
}