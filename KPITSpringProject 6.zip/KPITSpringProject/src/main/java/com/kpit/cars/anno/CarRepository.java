package com.kpit.cars.anno;

import java.util.ArrayList;


import org.springframework.stereotype.Repository;

//CRUD <-- facility must be given by Repository kind of classes


@Repository("carRepo") // In core java we call it as DAO, but in spring we call it as Repository
public class CarRepository {
	
	//if the intention of this class logic is to hold
	//collection of objects and perform DML operation with
	//search facility, then it is a Repository apart from 
	//Component

	ArrayList<Car> carList = new ArrayList<Car>();
	
	
	public CarRepository() {
		System.out.println("CarRepository().....");
		Car car1 = new Car("BMW");
		Car car2 = new Car("KIA Carnival");
		Car car3 = new Car("Audi Q7");
		Car car4 = new Car("Merc 320D");
		Car car5 = new Car("Bugati");
		
		carList.add(car1);
		carList.add(car2);
		carList.add(car3);
		carList.add(car4);
		carList.add(car5);
		
	}
	
	public Car getCarByName(String name) { //RETURNING CAR FROM LIST
		System.out.println("getCarByName(String).....");

		for (Car car : carList) {
			if(car.getModel().equals(name)) {
				return car;
			}
		}
		return null;
	}
	public ArrayList<Car> getAllCars() { //RETRIVE ENTIRE LIST
		System.out.println("getAllCars().....");

		return carList;
	}
	
	public void addCar(Car newCar) {
		System.out.println("addCar(Car).....");
		carList.add(newCar);
	}
	
	public Car updateCarByName(String name, String newName) { //UPDATE INTO LIST
		System.out.println("updateCar(String,String).....");

		for (Car car : carList) {
			if(car.getModel().equals(name)) {
				
				car.setModel(newName);	
				return car;
			
			}
		}
		return null;
	}
	
	public void deleteCarByName(String name) { //DELETE FROM LIST
		System.out.println("deleteCarByName(String).....");

		for (Car car : carList) {
			if(car.getModel().equals(name)) {
				
				carList.remove(car);
				break;
			
			}
		}
	}
	
}
