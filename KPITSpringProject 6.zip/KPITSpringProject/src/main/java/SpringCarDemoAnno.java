

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.kpit.cars.anno.Car;
import com.kpit.cars.anno.CarRepository;


public class SpringCarDemoAnno {

	public static void main(String[] args) {
		
		System.out.println("Trying to create spring container..with annotations based classes..");
		ApplicationContext container = new ClassPathXmlApplicationContext("myspring_anno.xml");
		System.out.println("Got the spring container...");
		
		System.out.println("\tRequesting the container to give me Car's object...");
		System.out.println("--------------------------");
		
		CarRepository carRepo = (CarRepository) container.getBean("carRepo");
		
		
		ArrayList<Car> cars=carRepo.getAllCars();
		
		for (Car car : cars) {
			System.out.println("Car model : "+car.getModel());
		}

		
	}

}




