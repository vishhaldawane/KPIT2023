package com.kpit.layer4;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kpit.layer1.Pizza;
import com.kpit.layer2.PizzaRepository;

//no web.xml | no dispatcherServlet | no spring-servlet.xml | no tomcat configuration | no bean configuration 
@RestController // Representational State Transfer  | xml | json 
@RequestMapping("/pizzas")
public class PizzaController  {

	@Autowired
	PizzaRepository pizzaRepo;
	
	public PizzaController() {
		System.out.println("PizzaController started...");
	}

	//KPIT Business team is aware that you are doing REST API
	//ONCE U KNOW ANGULAR
	
	//THEN U HAVE to COMBINE ANGULAR WITH SPRING REST
	
	//below URL would be used by YOUR ANGULAR TEAM
	@RequestMapping("/showAllPizzas") // http://localhost:8080/pizzas/showAllPizzas
	List<Pizza> findAllPizzas() {
			System.out.println("PizzController is finding all pizzas from PizzaRepository...");
			return pizzaRepo.selectAllPizzas();

	}
	
	//http://localhost:8080/pizzas/showSinglePizza/101
	@RequestMapping("/showSinglePizza/{pid}") // 
	Pizza findSinglePizzas(@PathVariable("pid") Integer x) {
			System.out.println("PizzController is finding  a single pizza from PizzaRepository...");
			return pizzaRepo.selectAPizza(x);

	}
	
	@RequestMapping("/welcome")
	String home() {
		System.out.println("Pizza Home");
		return "Welcome to Pizza House";
	}
	
	@RequestMapping("/order")
	String placeYourOrder() {
		System.out.println("Pizza Order Unit");
		return "Which Pizza you want?";
	}
}

// http://localhost:8080/pizzas/welcome