package com.kpit;

import org.springframework.stereotype.Component;

class A
{
	void fun() {
		
	}
}
class B extends A {

	@Override
	void fun1() {
		
	}
}

@Component
public class SavingsAccount {

	public SavingsAccount() {
		System.out.println("SavingsAccount ctr...");
	}
	
	public void withdraw(float amt) {
		System.out.println("SavingsAccount : withdraw() "+amt);
	}
	public void deposit(float amt) {
		System.out.println("SavingsAccount : deposit() "+amt);
	}

}
