package com.kpit.layer1;

public class Pizza {

	int pizzaId;
	String pizzaType;
	float pizzaCost;
	
	
	public Pizza(int pizzaId, String pizzaType, float pizzaCost) {
		super();
		this.pizzaId = pizzaId;
		this.pizzaType = pizzaType;
		this.pizzaCost = pizzaCost;
	}
	
	public int getPizzaId() {
		return pizzaId;
	}
	public void setPizzaId(int pizzaId) {
		this.pizzaId = pizzaId;
	}
	public String getPizzaType() {
		return pizzaType;
	}
	public void setPizzaType(String pizzaType) {
		this.pizzaType = pizzaType;
	}
	public float getPizzaCost() {
		return pizzaCost;
	}
	public void setPizzaCost(float pizzaCost) {
		this.pizzaCost = pizzaCost;
	}
	
	


}
