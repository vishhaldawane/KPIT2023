package com.kpit.layer2;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.kpit.layer1.Pizza;

@Repository
public class PizzaRepository {

	List<Pizza> allPizzas =new ArrayList();
	
	
	public PizzaRepository() {
		System.out.println("PizzaRepository() ");
		
		Pizza pizza1 = new Pizza(101,"Paneer Pizza",350);
		Pizza pizza2 = new Pizza(102,"Mashroom Pizza",250);
		Pizza pizza3 = new Pizza(103,"Chicken Pizza",600);
		Pizza pizza4 = new Pizza(104,"Veg Pizza",200);
		Pizza pizza5 = new Pizza(105,"Veg Corn Pizza",300);
		
		allPizzas.add(pizza1);
		allPizzas.add(pizza2);
		allPizzas.add(pizza3);
		allPizzas.add(pizza4);
		allPizzas.add(pizza5);
		
		
	}

	public List<Pizza> selectAllPizzas() {
		System.out.println("PizzaRepository : returning all pizzas : selectAllPizzas()");
		return allPizzas;
	}
	
	public Pizza selectAPizza(int pizzaIdToSearch) {
		System.out.println("PizzaRepository : returning a single pizza : selectAPizza(int)");
	
		for (Pizza pizza : allPizzas) {
			if(pizza.getPizzaId() == pizzaIdToSearch) {
				return pizza;
			}
		}
		return null;
	}
	
}
