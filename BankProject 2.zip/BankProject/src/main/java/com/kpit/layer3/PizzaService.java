package com.kpit.layer3;

public class PizzaService {

	public PizzaService() {
		// TODO Auto-generated constructor stub
	}

}
