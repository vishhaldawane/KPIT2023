package com.kpit.controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/burgers")
public class BurgerController {

	@RequestMapping("/greet") // http://localhost:8080/burgers/greet
	public String home() { //this function name can be any alian name
		
		return "<h1> Welcome to Burger House </h1>";
	}
	public BurgerController() {
		// TODO Auto-generated constructor stub
	}

}
