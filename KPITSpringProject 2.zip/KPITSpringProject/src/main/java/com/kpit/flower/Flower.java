package com.kpit.flower;

public interface Flower {
    void flowering();
}          
