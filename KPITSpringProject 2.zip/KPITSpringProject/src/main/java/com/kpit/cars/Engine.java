package com.kpit.cars;

public class Engine 
{
	Piston piston;
	
	public Engine(Piston piston) {
		System.out.println("Engine(Piston)...."+this.hashCode());

		this.piston = piston;
	}
	void startEngine() {
		System.out.println("Engine is ignited....");
	}
}