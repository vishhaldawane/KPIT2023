package com.kpit.cars;

public class CarTest {

	public static void main(String[] args) {
		
		Piston piston = new Piston("4Stroke");
		Engine engine = new Engine(piston);
		Car myCar = new Car(engine);
		myCar.startCar();
		System.out.println("----------");

		Piston piston1 = new Piston("6Stroke");
		Engine engine1 = new Engine(piston1);
		Car myCar1 = new Car(engine1);
		myCar1.startCar();
		
	}

}

