package com.kpit.cars;

public class Car
{
	Engine engine;
	
	Car(Engine engine) { //depends upon Engine, and Engine depends upon Piston, and Piston depends upon name
		System.out.println("Car(Engine)...."+this.hashCode());

		this.engine = engine;
	}
	void startCar() {
		System.out.println("Car is started....");
	}
}
