package com.kpit.cars;

public class Piston {
	String name;
	
	public Piston(String name) {
		System.out.println("Piston(String)...."+this.hashCode());
		this.name = name;
	}
	void startPiston() {
		System.out.println("Piston is fired....");
	}
}