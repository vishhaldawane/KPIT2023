import com.kpit.flower.Flower;
import com.kpit.flower.FlowerGarden;

public class FlowerTest {
   public static void main(String[] args) {
	
        /*Rose rose = new Rose(); // discourage this 
        rose.flowering();*/
	   
	   /*Lily lily = new Lily();
	   lily.flowering();*/
	   
	   /*Lotus lotus =  new Lotus();
	   lotus.flowering();*/
         
       FlowerGarden garden = new FlowerGarden(); //container - takes the responsibility to generate flowers of various types based on requirement
       Flower flower = garden.getFlower("sun");
       flower.flowering();
   }    
}  


// a local object ----> multithreading
// a local object ----> transaction management
// a local object ----> security management
// a local object ----> caching code
// a local object ----> pooling code
// a local object ----> networking code
// a local object -----> ORM
// a local object -----> Jdbc
// a local object -----> various wrappers 




// swiggy | zomato




// do u have to take care of their life cycles
// gardening
// pest control
// fertilizers
// sun light
// shadowing
// whole lot of business of flower management 
//garden to plant Roses / various types, colors
 

//garden to plant lilies


//pond


//garden to plant SunFlowers


