package com.kpit.flower;

public class SunFlower implements Flower {
	 public void flowering() {
	      System.out.println("SunFlower is flowering...");   
	    }  
}