package com.kpit.flower;

public class FlowerGarden //is a container to generate Flowers
{    
    public Flower getFlower() {
            Flower flower = new Rose();
            return flower;
    }    
    public Flower getFlower(String hint) {
    	 Flower flower = null;
    	 
    	if(hint.equals("lilies"))
    		flower = new Lily();
    	else if(hint.equals("roses"))
    		flower = new Rose();
    	else if(hint.equals("lotuses"))
    		flower = new Lotus();
    	else if(hint.equals("sun"))
    		flower = new SunFlower();
    	
        return flower;
}
}    
  