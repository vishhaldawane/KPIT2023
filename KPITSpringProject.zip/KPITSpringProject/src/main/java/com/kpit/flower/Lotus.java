package com.kpit.flower;

public class Lotus implements Flower {
    public void flowering() {
        System.out.println("Lotus is flowering...");   
      }    
  } 