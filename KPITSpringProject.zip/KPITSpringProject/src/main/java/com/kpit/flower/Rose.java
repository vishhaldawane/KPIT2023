package com.kpit.flower;

public class Rose implements Flower {
    public void flowering() {
      System.out.println("Rose is flowering...");   
    }    
}  