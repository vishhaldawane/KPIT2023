package com.kpit.flower;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringDemo {

	public static void main(String[] args) {
		
		ApplicationContext container = new ClassPathXmlApplicationContext("myspring.xml");
		System.out.println("Got the spring container...");
		
		System.out.println("Requesting the container to give me rose object...");
		Flower flower = (Flower) container.getBean("roses");
		System.out.println("Got a bean from the container...");
		flower.flowering();
	}

}
