package com.kpit.flower;

public class Lily implements Flower {
    public void flowering() {
        System.out.println("Lily is flowering...");   
      }    
  } 
