package com.kpit.layer3;

public class PizzaAlreadyExistException extends Exception {

	public PizzaAlreadyExistException() {
		// TODO Auto-generated constructor stub
	}

	public PizzaAlreadyExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PizzaAlreadyExistException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public PizzaAlreadyExistException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PizzaAlreadyExistException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
