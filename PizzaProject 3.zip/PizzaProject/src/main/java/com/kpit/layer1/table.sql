CREATE TABLE PIZZA
(
  pizzaid int primary key,
  pizzatype varchar(20),
  pizzacost float
);

INSERT INTO PIZZA VALUES (1,'CORN PIZZA',250);
INSERT INTO PIZZA VALUES (2,'PANEER PIZZA',350);
INSERT INTO PIZZA VALUES (3,'VEG PIZZA',275);
INSERT INTO PIZZA VALUES (4,'CHICKEN PIZZA',450);
INSERT INTO PIZZA VALUES (5,'MASHROOM PIZZA',400);

it is not compulsory to create this layer1 package

we are creating this file as a remedy, if the table is lost with data

