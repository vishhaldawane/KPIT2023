package com.kpit.flower;

public class SunFlower implements Flower {
	SunFlower() {
		System.out.println("SunFlower().."+this);
	}
	 public void flowering() {
	      System.out.println("SunFlower is flowering...");   
	    }  
}