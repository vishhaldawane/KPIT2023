package com.kpit.cars;

public class CarTest {

	public static void main(String[] args) {
		
		Piston piston = new Piston();
		piston.setPiston("4Stroke");
		
		Engine engine = new Engine();
		engine.setEngine(piston);
		
		Car myCar = new Car();
		myCar.setCar(engine);
		
		myCar.startCar();
		System.out.println("----------");

		
		
	}

}

