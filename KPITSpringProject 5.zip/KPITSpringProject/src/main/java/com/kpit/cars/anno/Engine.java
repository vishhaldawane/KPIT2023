package com.kpit.cars.anno;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("myEngine") //ctrl +shift +M will autoimport
public class Engine 
{
	Piston piston;
	
	@Autowired
	public Engine(Piston piston) {
		System.out.println("Engine(Piston)...."+this.hashCode());

		this.piston = piston;
	}
	
	/*public Engine() {
		System.out.println("Engine()...");
	}*/
	
	public void setEngine(Piston piston) { //property = engine
		System.out.println("setEngine(Piston)....<==invoked ");

		this.piston = piston;
	}
	void startEngine() {
		System.out.println("Engine is ignited....");
	}
}