package com.kpit.cars.anno;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("myPetrolEngine") //ctrl +shift +M will autoimport
public class PetrolEngine extends Engine
{
	Piston piston;
	
	@Autowired
	public PetrolEngine(Piston piston) {
		super(piston);
		System.out.println("PetrolEngine(Piston)...."+this.hashCode());

		
	}
	
	/*public Engine() {
		System.out.println("Engine()...");
	}*/
	
	public void setPetrolEngine(Piston piston) { //property = engine
		System.out.println("setPetrolEngine(Piston)....<==invoked ");

		this.piston = piston;
	}
	void startPetrolEngine() {
		System.out.println("PetrolEngine is ignited....");
	}
}