package com.kpit.cars.anno;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("myCar") // <--auto detected |  no need to write any XML <bean> tag NOW
@Scope("prototype")
public class Car
{
	@Autowired //at the field
	@Qualifier("myElectronicEngine")
	Engine engine;
	
	
	//at the constructor or a method
	/*@Autowired // how this Autowiring would detect which Engine to set here in the argument, cause all are engines	
	public Car(@Qualifier("myElectronicEngine") Engine engine) { //depends upon Engine, and Engine depends upon Piston, and Piston depends upon name
		System.out.println("Car(Engine)...."+engine.getClass().getTypeName());

		this.engine = engine;
	}*/
	
	/*public Car() {
		System.out.println("Car()...");
	}*/
	
	/*public void setCar(Engine engine) { //property = car | after the set[Car] <==here car is the property name | after the set
		System.out.println("setCar(Engine) <== ");
		this.engine = engine;
	}*/
	
	public void startCar() {
		System.out.println("Car is started...."+engine.getClass().getTypeName());
	}
}
