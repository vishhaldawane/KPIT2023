package entity;

public class OrmTest {

	public OrmTest() {
		// TODO Auto-generated constructor stub
	}

}
