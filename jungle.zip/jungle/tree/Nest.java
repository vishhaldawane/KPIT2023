package jungle.tree;

public class Nest {
	void allowEggs() {
		System.out.println("Bird's eggs are here..");
	}
}
