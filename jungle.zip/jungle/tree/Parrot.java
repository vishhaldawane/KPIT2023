package jungle.tree;

public class Parrot {
	void fly() {
		System.out.println("Parrot is flying...");
	}
}
