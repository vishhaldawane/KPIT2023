package jungle.river;

public class Frog {
	void jump() {
		System.out.println("frog is also jumping.....");
	}
	void swim() {
		System.out.println("Frog is swimming....");
	}
}
