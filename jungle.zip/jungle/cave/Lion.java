package jungle.cave;

public class Lion { //Lion.java

	void roaring() {
		System.out.println("lion is roaring...");
	}
	
	void watchAndWalk() {
		System.out.println("watching over...walking...");
	}
}
