package jungle.cave;


//child - same package
public class BengalTiger extends Tiger {

	void roaringBengalTiger() {
		//System.out.println("privateA   : "+privateA);
		
		//available even - non-child, but same package 
		//System.out.println("protectedB : "+protectedB);
		
		//System.out.println("publicC    : "+publicC);
		
		//same package
		//System.out.println("defaultD   : "+defaultD);

		
	}
}
