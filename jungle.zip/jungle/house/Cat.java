package jungle.house;

public class Cat {
	void meow() {
		System.out.println("Cat is meowing...");
	}
	
	void drinkMilk() {
		System.out.println("Cat is drinking milk....");
	}
	
	void chaseMice() {
		System.out.println("Chasing mice....");
	}
}
