package com.kpit.cars;

public class Engine 
{
	Piston piston;
	
	/*public Engine(Piston piston) {
		System.out.println("Engine(Piston)...."+this.hashCode());

		this.piston = piston;
	}*/
	
	public Engine() {
		System.out.println("Engine()...");
	}
	
	public void setEngine(Piston piston) { //property = engine
		System.out.println("setEngine(Piston)....<==invoked ");

		this.piston = piston;
	}
	void startEngine() {
		System.out.println("Engine is ignited....");
	}
}