package com.kpit.cars.anno;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("myCar") // <--auto detected |  no need to write any XML <bean> tag NOW
@Scope("prototype")
public class Car
{
	Engine engine;
	
	@Autowired
	public Car(Engine engine) { //depends upon Engine, and Engine depends upon Piston, and Piston depends upon name
		System.out.println("Car(Engine)...."+this.hashCode());

		this.engine = engine;
	}
	
	/*public Car() {
		System.out.println("Car()...");
	}*/
	
	public void setCar(Engine engine) { //property = car | after the set[Car] <==here car is the property name | after the set
		System.out.println("setCar(Engine) <== ");
		this.engine = engine;
	}
	void startCar() {
		System.out.println("Car is started....");
	}
}
