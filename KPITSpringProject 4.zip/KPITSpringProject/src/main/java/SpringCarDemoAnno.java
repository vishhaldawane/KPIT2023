

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.kpit.cars.anno.Car;
import com.kpit.flower.Flower;

public class SpringCarDemoAnno {

	public static void main(String[] args) {
		
		System.out.println("Trying to create spring container..with annotations based classes..");
		ApplicationContext container = new ClassPathXmlApplicationContext("myspring_anno.xml");
		System.out.println("Got the spring container...");
		
		System.out.println("\tRequesting the container to give me Car's object...");
		System.out.println("--------------------------");
		Car car1 = (Car) container.getBean("myCar"); //by its name
		System.out.println("Car 1 : "+car1.hashCode());
		
		System.out.println("-------------");
		
		Car car2 = (Car) container.getBean("myCar");
		System.out.println("Car 2 : "+car2.hashCode());

		System.out.println("-------------");

		
		Car car3 = (Car) container.getBean("myCar");
		System.out.println("Car 3 : "+car3.hashCode());

		
	}

}




